#!/bin/sh
set -e

echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "  WhatsApp Session Provider — Starting in Production"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

# Step 1: Apply pending database migrations
echo "→ Running database migrations..."
npx prisma migrate deploy || echo "⚠ Migration skipped (no pending migrations or DB not ready)"
echo "✓ Migrations step complete"

# Step 2: Generate Prisma client (in case schema changed)
echo "→ Generating Prisma client..."
npx prisma generate
echo "✓ Prisma client ready"

echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "  Starting Node.js server..."
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

# Step 3: Start the app (exec replaces shell so signals are forwarded)
exec node dist/server.js
